# This is like getting tools from your toy box to build something cool
import os  # This helps us find secret passwords stored on the computer
from langchain_openai import OpenAIEmbeddings, ChatOpenAI  # These are like smart robot brains
from langchain_community.document_loaders import TextLoader  # This reads books/files
from langchain_text_splitters import RecursiveCharacterTextSplitter  # This cuts big books into small pages
from langchain_chroma import Chroma  # This is like a magic filing cabinet that remembers everything
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder  # These teach the robot how to talk
from langchain_classic.chains.combine_documents import \
    create_stuff_documents_chain  # This helps put information together
from langchain_classic.chains.retrieval import create_retrieval_chain  # This helps find the right information
from langchain_classic.chains.history_aware_retriever import \
    create_history_aware_retriever  # This helps remember past conversations
import streamlit as st  # This creates a pretty website where you can chat
from langchain_community.chat_message_histories import \
    StreamlitChatMessageHistory  # This remembers what we talked about
from langchain_core.runnables.history import RunnableWithMessageHistory  # This makes the robot remember our chat

# Get the secret password to talk to the smart AI (like a key to a special clubhouse)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Create a robot that can turn words into numbers (so computers can understand them)
embeddings = OpenAIEmbeddings(api_key=OPENAI_API_KEY)

# Create the main smart robot brain that will answer your questions
llm = ChatOpenAI(model="gpt-4o", api_key=OPENAI_API_KEY)

# Read a book called "product-data.txt" - like opening a storybook
document = TextLoader("product-data.txt").load()

# Create scissors that cut the big book into small, easy-to-read pieces
# Each piece is about 1000 letters long, and pieces share 200 letters so nothing gets lost
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000,
                                               chunk_overlap=200)

# Use our scissors to cut the book into small pieces
chunks = text_splitter.split_documents(document)

# Put all the book pieces into a magic filing cabinet that can find things super fast
vector_store = Chroma.from_documents(chunks, embeddings)

# Create a helper that can search through our magic filing cabinet
retriever = vector_store.as_retriever()

# Teach the robot how to understand questions even when we refer to things we talked about before
# Like if you say "tell me more about it" - the robot knows what "it" means
contextualize_q_prompt = ChatPromptTemplate.from_messages(
    [
        ("system",
         "Given a chat history and the latest user question, formulate a standalone question that can be understood without the chat history."),
        MessagesPlaceholder("chat_history"),  # This is where old conversations go
        ("human", "{input}"),  # This is where your new question goes
    ]
)

# Teach the robot how to answer questions nicely
qa_prompt = ChatPromptTemplate.from_messages(
    [
        ("system", """You are an assistant for answering questions.
        Use the provided context to respond. If the answer 
        isn't clear, acknowledge that you don't know. 
        Limit your response to three concise sentences.
        {context}"""),  # This is where book information goes
        MessagesPlaceholder("chat_history"),  # This remembers what we talked about
        ("human", "{input}"),  # This is your question
    ]
)

# Create a smart searcher that remembers our previous conversations when looking for answers
history_aware_retriever = create_history_aware_retriever(llm, retriever, contextualize_q_prompt)

# Create a chain that puts documents together and sends them to the robot brain
qa_chain = create_stuff_documents_chain(llm, qa_prompt)

# Create the main robot that can search for information AND answer questions
rag_chain = create_retrieval_chain(history_aware_retriever, qa_chain)

# Create a memory box that remembers all our conversations (like a diary)
history_for_chain = StreamlitChatMessageHistory()

# Give our robot the ability to remember conversations by connecting it to the memory box
chain_with_history = RunnableWithMessageHistory(
    rag_chain,  # Our smart robot
    lambda session_id: history_for_chain,  # The memory box
    input_messages_key="input",  # Where questions go in
    history_messages_key="chat_history",  # Where memories are stored
    output_messages_key="answer"  # Where answers come out
)

# Create a title on our website that says "Chat with Document"
st.write("Chat with Document")

# Create a text box where you can type your questions
question = st.text_input("Your Question")

# If you typed something in the question box...
if question:
    # Send your question to the smart robot and get an answer back
    # "abc123" is like giving the conversation a name so the robot remembers it's you
    response = chain_with_history.invoke({"input": question}, {"configurable": {"session_id": "abc123"}})

    # Show the robot's answer on the website
    st.write(response['answer'])
