import os
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

# Load OpenAI key
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Initialize components
embeddings = OpenAIEmbeddings(api_key=OPENAI_API_KEY)
llm = ChatOpenAI(model="gpt-4o", api_key=OPENAI_API_KEY)

# Load and split document
document = TextLoader("product-data.txt").load()
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
chunks = text_splitter.split_documents(document)

# Create vector store and retriever
vector_store = Chroma.from_documents(chunks, embeddings)
retriever = vector_store.as_retriever()

# Define prompt
prompt_template = ChatPromptTemplate.from_messages([
    (
        "system",
        """You are an assistant for answering questions.
Use the provided context to respond.
If the answer isn't clear, acknowledge that you don't know.
Limit your response to three concise sentences.

Context:
{context}"""
    ),
    ("human", "{input}")
])

# Build the RAG pipeline using RunnablePassthrough
def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

rag_chain = (
    {"context": retriever | format_docs, "input": RunnablePassthrough()}
    | prompt_template
    | llm
    | StrOutputParser()
)

# Run interaction
print("Chat with Document (type 'exit' to quit)")

while True:
    question = input("\nEnter your question: ")
    if question.lower() in {"exit", "quit"}:
        break
    response = rag_chain.invoke(question)
    print("\nAnswer:", response)
