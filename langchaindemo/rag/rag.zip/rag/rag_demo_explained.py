# Import the 'os' module to access environment variables (like secret keys stored on your computer)
import os

# Import AI tools from LangChain for working with OpenAI models
from langchain_openai import OpenAIEmbeddings, ChatOpenAI

# Import tool to load text files into the program
from langchain_community.document_loaders import TextLoader

# Import tool to split large text into smaller, manageable pieces
from langchain_text_splitters import RecursiveCharacterTextSplitter

# Import Chroma - a database that stores text in a searchable format
from langchain_chroma import Chroma

# Import tools for creating structured conversations with AI
from langchain_core.prompts import ChatPromptTemplate

# Import tool that passes data through a pipeline unchanged
from langchain_core.runnables import RunnablePassthrough

# Import tool that extracts clean text from AI responses
from langchain_core.output_parsers import StrOutputParser

# Get the secret OpenAI API key from your computer's environment variables
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Create an embeddings object - converts text into numbers for computer comparison
embeddings = OpenAIEmbeddings(api_key=OPENAI_API_KEY)

# Create the AI language model (GPT-4o) that will answer questions
llm = ChatOpenAI(model="gpt-4o", api_key=OPENAI_API_KEY)

# Load the contents of "product-data.txt" file into memory
document = TextLoader("product-data.txt").load()

# Create a text splitter with specific settings:
# chunk_size=1000: each piece will be about 1000 characters long
# chunk_overlap=200: pieces will share 200 characters to keep context
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)

# Break the loaded document into smaller chunks using our splitter
chunks = text_splitter.split_documents(document)

# Create a vector database and store all text chunks in it for fast searching
vector_store = Chroma.from_documents(chunks, embeddings)

# Create a retriever - this searches the database for relevant information
retriever = vector_store.as_retriever()

# Create a conversation template that tells the AI how to behave
prompt_template = ChatPromptTemplate.from_messages([
    (
        "system",  # Instructions for the AI
        """You are an assistant for answering questions.
Use the provided context to respond.
If the answer isn't clear, acknowledge that you don't know.
Limit your response to three concise sentences.

Context:
{context}"""  # Placeholder where relevant text will be inserted
    ),
    ("human", "{input}")  # Placeholder where user's question will go
])


# Define a helper function that combines multiple document chunks into one text
def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)


# Build the complete RAG pipeline using a chain of operations:
rag_chain = (
    # Step 1: Get context from retriever and pass input through unchanged
        {"context": retriever | format_docs, "input": RunnablePassthrough()}
        # Step 2: Insert context and input into the prompt template
        | prompt_template
        # Step 3: Send the formatted prompt to the AI model
        | llm
        # Step 4: Extract clean text from the AI's response
        | StrOutputParser()
)

# Print welcome message with exit instructions
print("Chat with Document (type 'exit' to quit)")

# Start an infinite loop for continuous conversation
while True:
    # Ask user for their question
    question = input("\nEnter your question: ")

    # Check if user wants to quit (accepts "exit" or "quit" in any case)
    if question.lower() in {"exit", "quit"}:
        break  # Exit the loop and end the program

    # Send the question through our RAG pipeline and get an answer
    response = rag_chain.invoke(question)

    # Display the AI's answer to the user
    print("\nAnswer:", response)
